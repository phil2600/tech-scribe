// Created by iWeb 3.0.3 local-build-20110530

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({shadow_0:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#463c3c',opacity:0.800000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('MSAccessSQLi_files/MSAccessSQLiMoz.css')
fixAllIEPNGs('Media/transparent.gif');Widget.onload();fixupAllIEPNGBGs();IMpreload('MSAccessSQLi_files','shapeimage_2','0');IMpreload('MSAccessSQLi_files','shapeimage_2','1');IMpreload('MSAccessSQLi_files','shapeimage_2','2');IMpreload('MSAccessSQLi_files','shapeimage_2','3');IMpreload('MSAccessSQLi_files','shapeimage_2','4');IMpreload('MSAccessSQLi_files','shapeimage_2','5');IMpreload('MSAccessSQLi_files','shapeimage_2','6');IMpreload('MSAccessSQLi_files','shapeimage_2','7');IMpreload('MSAccessSQLi_files','shapeimage_2','8');IMpreload('MSAccessSQLi_files','shapeimage_2','9');IMpreload('MSAccessSQLi_files','shapeimage_2','10');IMpreload('MSAccessSQLi_files','shapeimage_2','11');IMpreload('MSAccessSQLi_files','shapeimage_2','12');IMpreload('MSAccessSQLi_files','shapeimage_2','13');IMpreload('MSAccessSQLi_files','shapeimage_2','14');IMpreload('MSAccessSQLi_files','shapeimage_2','15');IMpreload('MSAccessSQLi_files','shapeimage_2','16');IMpreload('MSAccessSQLi_files','shapeimage_2','17');IMpreload('MSAccessSQLi_files','shapeimage_2','18');IMpreload('MSAccessSQLi_files','shapeimage_2','19');IMpreload('MSAccessSQLi_files','shapeimage_2','20');IMpreload('MSAccessSQLi_files','shapeimage_2','21');IMpreload('MSAccessSQLi_files','shapeimage_2','22');IMpreload('MSAccessSQLi_files','shapeimage_2','23');IMpreload('MSAccessSQLi_files','shapeimage_2','24');IMpreload('MSAccessSQLi_files','shapeimage_2','25');IMpreload('MSAccessSQLi_files','shapeimage_2','26');IMpreload('MSAccessSQLi_files','shapeimage_2','27');applyEffects()}
function onPageUnload()
{Widget.onunload();}
